Ini adalah projek berjudul aplikasi Pembelian Tiket Kereta Api Sederhana dengan netbeans.
Nama Kelompok :
- Satrio Nandito
- Fatiha Eros Perdana
- Fauzi Al Rasid 

Cara menggunaan aplikasi ini adalah dengan memakai netbeans sebagai compiler&run nya.
Didalam netbeans :
- run aplikasinya ("coba" adalah main)
- silakan isi username dan password pada menu registrasi.
- login dengan username dan password yang telah dibuat diawal(jika tampilannya tidak muncul/muncul tapi kecil di tengah maka harus diperbesar dahulu/ditarik windownya).
- pilih stasiun tujuan,jam berangkat,jumlah tiket,kereta dan metode pembayaran lalu klik checkout, kalau sudah klik cetak.
- tiket anda sudah tercetak sesuai dengan yang dipilih pada tampilan sebelumnya.# pbo
