/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uknow
 */
public class coba {
   
    
    public static void main(String[] args){
        registrasi rg = new registrasi();
        rg.setVisible(true);
        rg.pack();
        rg.setLocationRelativeTo(null);
        rg.setDefaultCloseOperation(registrasi.EXIT_ON_CLOSE);
    }
    
    
}
